public interface AttackBehaviour {

    public abstract String attack(int power);

}