public interface FlyBehaviour {

    public abstract String fly();

}