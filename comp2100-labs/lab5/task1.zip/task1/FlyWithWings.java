public class FlyWithWings implements FlyBehaviour {

    public String fly() {
        return "I can fly!";
    }
}