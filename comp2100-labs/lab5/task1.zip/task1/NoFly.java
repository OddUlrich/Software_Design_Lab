public class NoFly implements FlyBehaviour {
    public String fly() {
        return "I cannot fly :(";
    }
}