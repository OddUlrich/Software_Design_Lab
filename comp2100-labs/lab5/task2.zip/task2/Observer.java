/**
 * @author dongwoo
 * @author huy.pham
 */
public interface Observer {
	public void update(Observable observable);
}
