/**
 * @author huy.pham
 */
public interface Quackable {
	public void quack();
}
